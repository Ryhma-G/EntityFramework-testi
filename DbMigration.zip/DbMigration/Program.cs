﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace DbMigration
{
   public class MeasurementContext : DbContext
    {
   public MeasurementContext() : base("SavoniaMeasurementsV2Entities") { }
   public DbSet<Measurement> Measurement { get; set; }
    }
    
    public class DataContext : DbContext
    {
        public DataContext() : base("SavoniaMeasurementsV2Entities") { }
        public DbSet<Data> Data { get; set; }
    }

    class Program
    {
        

        static void Main(string[] args)
        {
           using (var context = new DataContext())
            {
                
                try
                {
                   // var data = context.Data.Include(da => da.MeasurementID).ToList().Take(5);
                    var data = (from da in context.Data where da.MeasurementID >= 0 && da.MeasurementID < 100 select da);

                    foreach (var row in data)
                    {
                        Console.WriteLine("ID: " + row.MeasurementID + " Tag: " + row.Tag + " Value: " + row.Value + " LongValue: " + row.LongValue + " TextValue: " + row.TextValue + 
                            " BinaryValue: " + row.BinaryValue + " XmlValue: " + row.XmlValue);
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            Console.ReadKey();

            using (var context2 = new MeasurementContext())
            {

                try
                {
                    // var data = context.Data.Include(da => da.MeasurementID).ToList().Take(5);
                    var measurement = (from me in context2.Measurement where me.ID >= 1 && me.ID < 1000 select me);

                    foreach (var row in measurement)
                    {
                        Console.WriteLine(" ID: " + row.ID + " ProviderID: " + row.ProviderID + " Object: " + row.Object + " Tag: " + row.Tag + " Timestamp: " + row.Timestamp + " Note: " + row.Note +
                            " Location: " + row.Location + " RowCreateTimestamp: " + row.RowCreatedTimestamp + " KeyId: " + row.KeyId);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            Console.ReadKey();
        }
    }
}
